STILL ON — Gulsa portfolio site
================================

WHAT'S HERE
  index.html   The entire website in one file. Images, video frames,
               fonts, styles and scripts are all embedded — there are
               no other files to keep track of.

TO VIEW IT
  Double-click index.html. It opens in your browser and works offline.

TO PUT IT ON YOUR DOMAIN
  Netlify (easiest, free):
    1. Go to app.netlify.com/drop
    2. Drag this whole folder onto the page
    3. It goes live instantly on a temporary address
    4. Site settings -> Domain management -> add your own domain

  Any normal web host:
    Upload index.html to your hosting root (usually public_html
    or www). That's it.

NOTE
  Because everything is embedded, index.html is around 10 MB.
  That's normal for this site — it's carrying the full scroll
  video sequences inside it.

Made by Drolgo9 — Discord: Drolgo9
